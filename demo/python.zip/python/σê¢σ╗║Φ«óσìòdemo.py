import requests

url = "https://openapi.wbfex.com/open/api/create_order"

payload = "api_key=78002a0582d0dcad3447a28340d45a0d&price=0.306201&side=SELL&symbol=wtusdt&time=1564124760170&volume=0.2&sign=f2f061193839f4891ba5946b842036a6&type=1"
headers = {
    'content-type': "application/x-www-form-urlencoded",
    'cache-control': "no-cache",
    'postman-token': "40ff9187-ba33-bfb3-024f-fb4d05b437d6"
    }

response = requests.request("POST", url, data=payload, headers=headers)

print(response.text)
