#!/usr/bin/env python
# -*- coding: utf-8 -*-
import hashlib

import requests
import json

time = 1564124760170
secret_key = "b76e9bd9b3b2e578a6b7f581d22857c4"
api_key = "78002a0582d0dcad3447a28340d45a0d"
order_id = 207939
symbol = 'wtusdt'


def create_sign(api_key, order_id, symbol, time):
    temp_sign = 'api_key' + api_key + 'order_id' + str(order_id) + 'symbol' + symbol + 'time' + str(
        time) + secret_key
    md_sign = hashlib.md5()
    md_sign.update(temp_sign.encode())
    test_sign1 = md_sign.hexdigest()
    return test_sign1




if __name__ == "__main__":
    print create_sign(api_key, order_id, symbol, time)
