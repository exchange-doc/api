#!/usr/bin/env python
# _*_coding:utf-8_*_
import hashlib
import urllib2
import time

api_key = "78002a0582d0dcad3447a28340d45a0d"
time = int(time.time())
secret_key = "b76e9bd9b3b2e578a6b7f581d22857c4"


# 生成待签名的字符串
def create_sign(api_key, time, secret_key):
    temp_sign = 'api_key' + api_key + 'time' + str(time) + secret_key
    md_sign = hashlib.md5()
    md_sign.update(temp_sign.encode())
    test_sign1 = md_sign.hexdigest()
    print test_sign1
    return test_sign1


# 资产余额查询
def get_balance(api_key, time, sign):
    url = "https://openapi.wbfex.com/open/api/user/account?api_key=" + api_key + "&time=" + str(time) + "&sign=" + sign
    req = urllib2.Request(url)
    res_data = urllib2.urlopen(req)
    res = res_data.read()
    return res


if __name__ == "__main__":
    print get_balance(api_key, time, sign)
