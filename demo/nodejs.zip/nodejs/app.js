
const BigNumber = require('bignumber.js');
const md5 = require('md5');
const sdk = require('./lib');

var api_key = '8e3d17cf7f499bd515479bf47c0666f0'
var secret_key = '807411e20b0ac615efa861964c3b87a0'

var time = (new Date()).getTime();



var preSign = 'api_key' + api_key + 'time' + time + secret_key
var sign = md5(preSign)


sdk.getBalance(
    api_key,
    time,
    sign
)

