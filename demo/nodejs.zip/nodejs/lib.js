const request = require('request');

var sdk = {};
sdk.buy = function(symbol, price, volume, api_key, time, sign) {
    console.log(`volume ${volume} price ${price}  symbol ${symbol}`)

    let body = {
        side: 'BUY',
        type: 1, // 限价委托
        volume,
        price,
        symbol,
        // fee_is_user_exchange_coin: 0,
        api_key,
        time,
        sign
    }
    console.log(body);
    request({
        url: `https://openapi.wbfex.com/open/api/create_order`,
        method: 'post',
        json: true,
        body
    },function(err, response, body) {
        if (err) {
            reject(err);
        }
        // sdk的交易体数组
        const xx = JSON.parse(body).data;
        console.log(xx)
    })
}

sdk.getBalance = function(api_key, time, sign) {
    request(`https://openapi.wbfex.com/open/api/user/account?api_key=${api_key}&time=${time}&sign=${sign}`,function(err, response, body) {
        if (err) {
            reject(err);
        }
        // sdk的交易体数组
        const xx = JSON.parse(body).data;
        console.log(xx)
    })

}

sdk.getDept = function(symbol, type) {
    request(`https://openapi.wbfex.com/open/api/market_dept?symbol=${symbol}&type=${type}`,function(err, response, body) {
        if (err) {
            reject(err);
        }
        // sdk的交易体数组
        const xx = JSON.parse(body).data;
        console.log(xx)
    })
}

module.exports = sdk;