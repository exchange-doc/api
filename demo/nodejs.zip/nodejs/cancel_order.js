var request = require("request");

var options = { method: 'POST',
  url: 'https://openapi.wbfex.com/open/api/cancel_order',
  headers:{},
  form:
   { api_key: '78002a0582d0dcad3447a28340d45a0d',
     order_id: '207939',
     sign: '9580c6c40bbca4b76bb441751e5aaf99',
     symbol: 'wtusdt',
     time: '1564124760170'
    } };

request(options, function (error, response, body) {
  if (error) throw new Error(error);

  console.log(body);
});
~
