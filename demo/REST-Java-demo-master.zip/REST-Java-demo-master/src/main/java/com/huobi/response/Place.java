package com.huobi.response;

/**
 * @Author ISME
 * @Date 2018/1/14
 * @Time 17:10
 */

public class Place {
}
