package com.huobi.response;

/**
 * @Author ISME
 * @Date 2018/1/14
 * @Time 15:47
 */

public class Currencys {
}
