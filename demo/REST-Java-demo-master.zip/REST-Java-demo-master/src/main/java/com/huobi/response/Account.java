package com.huobi.response;

/**
 * @Author ISME
 * @Date 2018/1/14
 * @Time 16:02
 */
public class Account {
    public long id;
    public String type;
    public String state;
}
