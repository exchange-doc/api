# REST-Java-demo

```java
String api_key = ""; // huobi申请的apiKey
String secret_key = ""; // huobi申请的secretKey
```
 替换成自己的APIKEY 
